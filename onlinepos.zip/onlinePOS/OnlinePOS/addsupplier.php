
<form action="savesupplier.php" method="post">
Team Member:<br />
<input name="a" type="text" size="70" /><br />
Member Number:<br />
<input name="b" type="text" size="70" />
<br />
Address:<br />
<input name="c" type="text" size="70" /><br />
Contact Number:<br />
<input name="d" type="text" size="70" /><br />
Birth Day:<br />
<input name="e" type="text" size="70" /><br />
<input name="submit" type="submit" value="save">
</form>
