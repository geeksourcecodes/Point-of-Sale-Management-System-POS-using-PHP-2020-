<form action="saveexec.php" method="post">
code:<br />
<input name="a" type="text" /><br />
description:<br />
<input name="c" type="text" size="70" />
<br />
quantity:<br />
<input name="d" type="text" /><br />
price:<br />
<input name="e" type="text" /><br />
<input name="submit" type="submit" value="save">
</form>
